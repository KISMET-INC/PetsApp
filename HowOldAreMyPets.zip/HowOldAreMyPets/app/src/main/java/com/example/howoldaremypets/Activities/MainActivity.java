package com.example.howoldaremypets.Activities;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.example.howoldaremypets.Data.DatabaseHandler;
import com.example.howoldaremypets.Model.Pet;
import com.example.howoldaremypets.R;
import com.example.howoldaremypets.Util.Constants;
import com.example.howoldaremypets.Util.UtilMethods;


import java.io.FileInputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private EditText petNameInput;
    private EditText petBirthdayInput;
    private AlertDialog.Builder dialogBuilder;
    private AlertDialog dialog;
    private Button saveButton;
    private DatabaseHandler db;
    private UtilMethods util;
    private ImageView imageButton;
    private static final int SELECT_PICTURE = 100;
    private Uri pickedImageUri;
    private byte[] imageByte;
    public static final int REQUEST_CODE = 1;
    String imagePath;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (verifyPermissions()== true ) {
            setContentView(R.layout.activity_main);

            db = new DatabaseHandler(this);

            byPassActivity();

            Toolbar toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);

            FloatingActionButton fab = findViewById(R.id.fab);
            fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    createPopUpDialog();
                }
            });
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void createPopUpDialog() {

        dialogBuilder = new AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.popup, null);
        petNameInput = (EditText) view.findViewById(R.id.petName);
        petBirthdayInput = (EditText) view.findViewById(R.id.petBirthday);
        saveButton = (Button) view.findViewById(R.id.savePet);
        imageButton = (ImageView) view.findViewById(R.id.imageButton);

        dialogBuilder.setView(view);
        dialog = dialogBuilder.create();
        dialog.show();


        /*    //hard code for test purposes
        //TODO Remove test code
        petNameInput.setText("rhapsody");
        petBirthdayInput.setText("12/12/2009");
*/

        saveButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {


                Boolean isValidInput = util.isValidInput(petBirthdayInput.getText().toString().trim());

                if (!petNameInput.getText().toString().isEmpty() && !petBirthdayInput.getText().toString().trim().isEmpty() && isValidInput) {
                    Boolean isValidDate = util.dateValidation(petBirthdayInput.getText().toString().trim());

                    if (isValidDate) {

                        savePetToDB(v);
                    } else {
                        Snackbar.make(v, "Please enter a valid date  MM/DD/YYYY ", Snackbar.LENGTH_LONG).show();
                    }

                } else

                    Snackbar.make(v, "Please enter a valid name and petBirthdayTextView", Snackbar.LENGTH_LONG).show();
            }
        });

        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });

    }

    private void savePetToDB(View v) {
        Pet pet = new Pet();

        String newPetData = util.capitalizeFirstLetter(petNameInput.getText().toString().trim());
        String newBirthdayData = petBirthdayInput.getText().toString().trim();
        String imageUriFromGallery = pickedImageUri.toString();

        byte[] createdByteImage = null;

        try {

            //get address of createdByteImage chosen from gallery
            FileInputStream fis = new FileInputStream(imagePath);

            //create image from fis Uri info
            createdByteImage = new byte[fis.available()];
            fis.read(createdByteImage);

            ContentValues values = new ContentValues();
            values.put(Constants.KEY_IMAGE_BYTE, createdByteImage);

            fis.close();


        } catch (IOException e) {
            e.printStackTrace();
        }

        //create a JAVA pet object from input and gallery Data
        pet.setName(newPetData);
        pet.setBirthdayString(newBirthdayData);
        pet.setImageURI(imageUriFromGallery);
        pet.setImageBYTE(createdByteImage);

        Log.d("PETBYTE ", pet.getImageBYTE().toString()) ;

        db.addPet(pet);
        db.close();


        Snackbar.make(v, "Pet Added!", Snackbar.LENGTH_LONG).show();
        dialog.dismiss();
        //start a new activity
        startActivity(new Intent(MainActivity.this, ListActivity.class));

    }

    public void byPassActivity() {
        //checks if DB is empty

        if (db.getCount() > 0) {
            startActivity(new Intent(MainActivity.this, ListActivity.class));
            finish();
            db.close();
        }
    }

    private void openGallery() {
//        CropImage.activity()
//                .setGuidelines(CropImageView.Guidelines.ON)
//                .start(this);
        Intent gallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        startActivityForResult(gallery, SELECT_PICTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == SELECT_PICTURE) {

            pickedImageUri = data.getData();
            imageButton.setImageURI(pickedImageUri);

            String[] filePath = { MediaStore.Images.Media.DATA };
            Cursor cursor = getContentResolver().query(pickedImageUri, filePath, null, null, null);
            cursor.moveToFirst();
            imagePath = cursor.getString(cursor.getColumnIndex(filePath[0]));
            Log.d("image path", imagePath);

        }
    }

    private boolean verifyPermissions() {
        String[] permissions = {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA};
        if (ContextCompat.checkSelfPermission(this, permissions [0] ) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, permissions [1] ) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, permissions [2] ) == PackageManager.PERMISSION_GRANTED) {
            return true;

    } else {
            ActivityCompat.requestPermissions( this, permissions, REQUEST_CODE);
            return true;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        verifyPermissions();
    }

}
