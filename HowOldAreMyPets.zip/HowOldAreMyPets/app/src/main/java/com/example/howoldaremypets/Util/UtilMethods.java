package com.example.howoldaremypets.Util;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import com.example.howoldaremypets.Data.DatabaseHandler;
import com.example.howoldaremypets.Model.Pet;
import com.example.howoldaremypets.R;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;
import java.util.GregorianCalendar;

import static android.support.v4.app.ActivityCompat.startActivityForResult;

public class UtilMethods {


    public static long ageInYears (Long ageInMilliseconds) {
        long years = ageInMilliseconds / 1000 / 60 / 60/ 24 / 365;
        return years;

    }

    public static long ageInMonths (Long ageInMilliseconds) {
        long months = ageInMilliseconds / 2629746000L % 12;
        return months;

    }

    public static long ageInMilliseconds (int year, int month, int day) {
        month = month - 1;
        Date birthdate = new GregorianCalendar(year, month, day).getTime();
        Date today = new Date();

        long ageInMilliseconds = today.getTime() -  birthdate.getTime();

        return ageInMilliseconds;
    }

    public static long ageInMilliseconds2 (long bdayInMilliseconds ) {
        Date today = new Date();

        long ageInMilliseconds = today.getTime() - bdayInMilliseconds;

        return ageInMilliseconds;
    }

    public static String  dateToString ( Date date) {
        long newDateString = date.getTime();
        String dateString = DateFormat.format("E MMMM dd, yyyy", new Date(newDateString)).toString();
        return dateString;
    }




    public static String reformatDateString (String stringDate) {
        Date date1 = stringToDate(stringDate);
        String prettyDate = dateToString(date1);

        return prettyDate;
    }

    public static Date stringToDate (String dateString) {

        String[] array =   dateString.split("/");
        int month = Integer.valueOf(array[0])- 1;
        int day = Integer.valueOf(array[1]);
        int year = Integer.valueOf(array[2]);

           Date date = new GregorianCalendar(year, month, day).getTime();


        return date;

    }

    public static boolean dateValidation(String dateString) {
        Date date = null;
        String[] array = dateString.split("/");
        int month = Integer.valueOf(array[0]) - 1;
        int day = Integer.valueOf(array[1]);
        int year = Integer.valueOf(array[2]);

        if ((month >= 0 && month <= 12) && (day >= 1 && day <= 31) && (year > 1000)) {
            return true;

        } else {
            return false;
        }

    }

    public static boolean isValidInput (String dateString) {

        if (dateString.matches("^[^a-zA-Z]*")) {
            return true;
        } else {
            return false;
        }


    }

    public static String capitalizeFirstLetter(String nameString){
        String firstLetter = nameString.substring(0,1).toUpperCase();
        String restOfName = nameString.substring(1);

        return firstLetter + restOfName;

    }


}
