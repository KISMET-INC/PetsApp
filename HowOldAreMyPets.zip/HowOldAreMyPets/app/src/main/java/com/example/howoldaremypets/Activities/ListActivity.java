package com.example.howoldaremypets.Activities;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import com.example.howoldaremypets.Data.DatabaseHandler;
import com.example.howoldaremypets.Model.Pet;
import com.example.howoldaremypets.R;
import com.example.howoldaremypets.UI.RecyclerViewAdapter;
import com.example.howoldaremypets.Util.Constants;
import com.example.howoldaremypets.Util.UtilMethods;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class ListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RecyclerViewAdapter recyclerViewAdapter;
    private List<Pet> petsListFromDB;
    private List<Pet> petListForRecycleViewer;
    private DatabaseHandler db;

    private AlertDialog.Builder dialogBuilder;
    private AlertDialog dialog;
    private LayoutInflater inflater;
    private UtilMethods util;
    private EditText petNameInput;
    private EditText petBirthdayInput;
    private Button saveButton;

    private ImageButton imageButton;
    private static int SELECT_PICTURE = 100;
    private Uri pickedImageUri;
    private byte[] imageByte;
    public static final int REQUEST_CODE = 1;
    String imagePath;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                addPetPopup();



            }
        });

        db = new DatabaseHandler(this);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerViewID);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        petsListFromDB = new ArrayList<>();  // Holds all pets received from DB
        petListForRecycleViewer = new ArrayList<>(); // Captures all pets from petsListFromDB to be viewed by Recycler Viewer

        //get items from database

        petsListFromDB = db.getAllPets();

        for (Pet c : petsListFromDB) {
            Pet pet = new Pet();
            pet.setName(c.getName());
            pet.setBirthdayString(c.getBirthdayString());
            pet.setBirthdayLong(c.getBirthdayLong());
            pet.setId(c.getId());
            pet.setImageURI(c.getImageURI());
            pet.setImageBYTE(c.getImageBYTE());

            Log.d("petByteListAct", pet.getImageURI().toString());

            petListForRecycleViewer.add(pet);
        }

        recyclerViewAdapter = new RecyclerViewAdapter(this, petListForRecycleViewer);
        recyclerView.setAdapter(recyclerViewAdapter);
        recyclerViewAdapter.notifyDataSetChanged();
    }



    private void addPetPopup() {

        dialogBuilder = new AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.popup, null);
        petNameInput = (EditText) view.findViewById(R.id.petName);
        petBirthdayInput = (EditText) view.findViewById(R.id.petBirthday);
        saveButton = (Button) view.findViewById(R.id.savePet);
        imageButton = (ImageButton) view.findViewById(R.id.imageButton);

        dialogBuilder.setView(view);
        dialog = dialogBuilder.create();
        dialog.show();

      /*  //hard code for test purposes
        //TODO Remove test code
        petNameInput.setText("rhapsody");
        petBirthdayInput.setText("12/12/2009");
*/


        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Boolean isValidInput = util.isValidInput(petBirthdayInput.getText().toString().trim());

                if (!petNameInput.getText().toString().isEmpty() && !petBirthdayInput.getText().toString().trim().isEmpty() && isValidInput) {
                    Boolean isValidDate = util.dateValidation(petBirthdayInput.getText().toString().trim());

                    if (isValidDate) {

                        savePetToDB(v);


                       petListForRecycleViewer.clear();
                        recyclerViewAdapter.notifyDataSetChanged();


                        petsListFromDB = db.getAllPets();

                        Log.d("pet DB list length", Integer.toString(db.getCount()));
                        Log.d("pet list length", Integer.toString(petsListFromDB.size()));
                        Log.d("pet list recycler", Integer.toString(petListForRecycleViewer.size()));



                        for (Pet c : petsListFromDB) {
                            Pet pet = new Pet();
                            pet.setName(c.getName());
                            pet.setBirthdayString(c.getBirthdayString());
                            pet.setBirthdayLong(c.getBirthdayLong());
                            pet.setId(c.getId());
                            pet.setImageURI(c.getImageURI());
                            pet.setImageBYTE(c.getImageBYTE());

                            petListForRecycleViewer.add(pet);


                            dialog.dismiss();
                        }
                        recyclerViewAdapter.notifyDataSetChanged();

                        Log.d("Happening", "validation accepted");



                    } else {
                        Snackbar.make(v, "Please enter a valid date  MM/DD/YYYY ", Snackbar.LENGTH_LONG).show();
                    }

                } else {

                    Snackbar.make(v,"Please enter a valid name and petBirthdayTextView", Snackbar.LENGTH_LONG).show();
            }
                }
        });

        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });
    }


    private void savePetToDB(View v) {
        Pet pet = new Pet();
        String newPetData = util.capitalizeFirstLetter(petNameInput.getText().toString().trim());
        String newBirthdayData = petBirthdayInput.getText().toString().trim();
        String imageUriFromGallery = pickedImageUri.toString();

        byte[] createdByteImage = null;

        try {

            //get address of createdByteImage chosen from gallery
            FileInputStream fis = new FileInputStream(imagePath);

            //create image from fis Uri info
            createdByteImage = new byte[fis.available()];
            fis.read(createdByteImage);

            ContentValues values = new ContentValues();
            values.put(Constants.KEY_IMAGE_BYTE, createdByteImage);

            fis.close();


        } catch (IOException e) {
            e.printStackTrace();
        }

        //create a JAVA pet object from input and gallery Data
        pet.setName(newPetData);
        pet.setBirthdayString(newBirthdayData);
        pet.setImageURI(imageUriFromGallery);
        pet.setImageBYTE(createdByteImage);


        db.addPet(pet);


        petsListFromDB.add(pet);
        petListForRecycleViewer.add(pet);

        db.close();


        Snackbar.make(v, "Pet Added!", Snackbar.LENGTH_LONG).show();
        dialog.dismiss();
      /*  //start a new activity
        startActivity(new Intent(MainActivity.this, ListActivity.class));*/

    }


    private void openGallery() {
        Intent gallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        startActivityForResult(gallery, SELECT_PICTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == SELECT_PICTURE) {

            pickedImageUri = data.getData();
            imageButton.setImageURI(pickedImageUri);

            String[] filePath = { MediaStore.Images.Media.DATA };
            Cursor cursor = getContentResolver().query(pickedImageUri, filePath, null, null, null);
            cursor.moveToFirst();
            imagePath = cursor.getString(cursor.getColumnIndex(filePath[0]));
            Log.d("image path", imagePath);


        }
    }




    }









