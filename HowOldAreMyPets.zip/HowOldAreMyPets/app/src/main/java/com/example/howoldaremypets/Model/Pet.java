package com.example.howoldaremypets.Model;

import android.util.Log;

import com.example.howoldaremypets.Util.UtilMethods;

public class Pet {

    private UtilMethods util;

    private String name;
    private String birthdayString;
    private long birthdayLong;
    private int id;
    private String imageURI;
    private byte[] imageBYTE;



    public Pet() {

    }

    public Pet(String name, String birthdayString, int id) {
        this.name = name;
        this.birthdayString = birthdayString;
        this.id = id;

       long newlong = util.stringToDate(this.getBirthdayString()).getTime();
        this.birthdayLong = newlong;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBirthdayString() {
        return birthdayString;
    }

    public void setBirthdayString(String birthdayString) {
        this.birthdayString = birthdayString;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public long getBirthdayLong() {
        return birthdayLong;
    }

    public void setBirthdayLong(long birthdayLong) {
       util.stringToDate(this.getBirthdayString()).getTime();

        this.birthdayLong = util.stringToDate(this.getBirthdayString()).getTime();
    }

    public String getImageURI() {
        return imageURI;
    }

    public void setImageURI(String imageURI) {
        this.imageURI = imageURI;
    }

    public byte[] getImageBYTE() {
        return imageBYTE;
    }

    public void setImageBYTE(byte[] imageBYTE) {
        this.imageBYTE = imageBYTE;
    }



}
