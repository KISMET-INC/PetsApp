package com.example.howoldaremypets.UI;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.howoldaremypets.Data.DatabaseHandler;
import com.example.howoldaremypets.Model.Pet;
import com.example.howoldaremypets.R;
import com.example.howoldaremypets.Util.UtilMethods;

import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

    private Context context;
    private List<Pet> petListForPosition;
    private AlertDialog.Builder alertDialogBuilder;
    private AlertDialog dialog;
    private LayoutInflater inflater;
    private UtilMethods util;
    public static final int PICK_IMAGE = 100;

    byte[] imageByte;
    Uri imageUri;

    public RecyclerViewAdapter(Context context, List<Pet> petListForPosition) {
        this.context = context;
        this.petListForPosition = petListForPosition;
    }

    @Override
    public RecyclerViewAdapter.ViewHolder onCreateViewHolder( ViewGroup parent, int i) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_row,parent,false);

        return new ViewHolder(view, context);
    }

    @Override
    public void onBindViewHolder( RecyclerViewAdapter.ViewHolder holder, int position) {


        Pet pet = petListForPosition.get(position);

        long milliAge = util.ageInMilliseconds2(pet.getBirthdayLong());
        long years = util.ageInYears(milliAge);
        long months = util.ageInMonths(milliAge);
        //////////////////
        byte[] imageBYTE = pet.getImageBYTE();
        Log.d("imagebyte ", pet.getImageURI().toString());


        String prettyDate = util.reformatDateString(pet.getBirthdayString());
        String age = years + " years " + months + " months";
        //////////////
        Bitmap bitmap = BitmapFactory.decodeByteArray(imageBYTE, 0, imageBYTE.length);


        Uri uri = Uri.parse(pet.getImageURI());
        holder.petNameTextView.setText(pet.getName());
        holder.petBirthdayTextView.setText(prettyDate);
        holder.age.setText(age);
       holder.petImageIcon.setImageBitmap(bitmap);


        /*try {

           // URL url = new URL(pet.getImageURI());

         //   holder.petImageIcon.setImageURI(Uri.parse(pet.getImageURI()));

        } catch (Exception e) {
            Log.d("oops problem", "problem");
            holder.petImageIcon.clearFocus();

        }*/

        Log.d("URI", String.valueOf(pet.getImageURI()));
        Log.d("Name", String.valueOf(pet.getName()));

        // holder.birthdayLong.setText(String.valueOf(pet.getBirthdayLong()));
        //  holder.petID.setText(String.valueOf(pet.getId()));


    }

    @Override
    public int getItemCount() {
        return petListForPosition.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        public TextView petNameTextView;
        public TextView petBirthdayTextView;
        public TextView birthdayLong;
        public Button editButton;
        public Button deleteButton;
        public TextView petID;
        public TextView age;
        public ImageButton imageButton;
        public ImageView petImageIcon;

        public int id;

        public ViewHolder(View view, Context cxt) {
            super(view);

            context = cxt;

            petImageIcon = (ImageView) view.findViewById(R.id.petImage);
            imageButton = (ImageButton) view.findViewById(R.id.imageButton);
            petNameTextView = (TextView) view.findViewById(R.id.name);
            petBirthdayTextView = (TextView) view.findViewById(R.id.birthdayString);
            editButton = (Button) view.findViewById(R.id.editButton);
            deleteButton = (Button) view.findViewById(R.id.deleteButton);
        //    petID = (TextView) view.findViewById(R.id.ID);
            age = (TextView) view.findViewById(R.id.age);

            editButton.setOnClickListener(this);
            deleteButton.setOnClickListener(this);




        }

        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.editButton:
                    int position = getAdapterPosition();
                    Pet pet = petListForPosition.get(position);
                    editPet(pet);

                    break;

                case R.id.deleteButton:
                     position = getAdapterPosition();
                     pet = petListForPosition.get(position);
                    deleteItem(pet.getId());

                    break;

            }

        }



        public void deleteItem(final int id) {
            //create alert dialog
            alertDialogBuilder = new AlertDialog.Builder(context);
            inflater = LayoutInflater.from(context);
            View view = inflater.inflate(R.layout.confirmation_dialog, null);

            Button noButton = (Button) view.findViewById(R.id.noButton);
            Button yesButton = (Button) view.findViewById(R.id.yesButton);

            alertDialogBuilder.setView(view);
            dialog = alertDialogBuilder.create();

            dialog.show();

            noButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            yesButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DatabaseHandler db = new DatabaseHandler(context);
                    Log.d("position:", String.valueOf(getAdapterPosition()));

                    db.deletePet(id);
                     petListForPosition.remove(getAdapterPosition());
                    notifyItemRemoved(getAdapterPosition());
                    dialog.dismiss();


                    Log.d("Item:", String.valueOf(db.getCount()));
                }
            });

            }

            public void editPet (final Pet pet) {

            alertDialogBuilder = new AlertDialog.Builder(context);

            inflater = LayoutInflater.from(context);

            final View view = inflater.inflate(R.layout.popup, null);

                final EditText petName = (EditText) view.findViewById(R.id.petName);
                final EditText petBirthday = (EditText) view.findViewById(R.id.petBirthday);
                Button saveButton = (Button) view.findViewById(R.id.savePet);
                TextView popupTitle = (TextView) view.findViewById(R.id.title);
                ImageButton imageButton = (ImageButton) view.findViewById(R.id.imageButton);

                imageUri = Uri.parse(pet.getImageURI());

                popupTitle.setText((R.string.edit_pet));

                petName.setText(pet.getName());
                petBirthday.setText(pet.getBirthdayString());

                imageByte = pet.getImageBYTE();
                Bitmap bitmap = BitmapFactory.decodeByteArray(imageByte, 0 , imageByte.length);
                imageButton.setImageBitmap(bitmap);




                alertDialogBuilder.setView(view);
                dialog = alertDialogBuilder.create();

                dialog.show();

                saveButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        DatabaseHandler db = new DatabaseHandler(context);
                        pet.setName(util.capitalizeFirstLetter(petName.getText().toString().trim()));
                        pet.setBirthdayString(petBirthday.getText().toString().trim());



                        Boolean isValidInput = util.isValidInput(petBirthday.getText().toString().trim());

                        if (!petName.getText().toString().isEmpty() && !petBirthday.getText().toString().isEmpty() && isValidInput) {
                            Boolean isValidDate = util.dateValidation(petBirthday.getText().toString().trim());

                            if (isValidDate) {


                                long newBirthdayLong = util.stringToDate(petBirthday.getText().toString()).getTime();
                                pet.setBirthdayLong(newBirthdayLong);


                                db.updatePet(pet);
                                notifyItemChanged(getAdapterPosition(), pet);
                                dialog.dismiss();

                            } else {

                                Snackbar.make(v, "Please enter a valid date  MM/DD/YYYY ", Snackbar.LENGTH_LONG).show();
                            }

                        } else {

                            Snackbar.make(v, "Please enter a valid name and petBirthdayTextView", Snackbar.LENGTH_LONG).show();
                        }
                    }
                });




            }
        }



}


